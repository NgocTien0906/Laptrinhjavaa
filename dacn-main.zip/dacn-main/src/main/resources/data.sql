insert into categories(name, type)
values ('Tiền Lương', 'DEPOSIT'),
       ('Tiền Thưởng', 'DEPOSIT'),
       ('Tiền Tiết Kiệm', 'DEPOSIT'),
       ('Tiền Lãi', 'DEPOSIT');

insert into categories(name, type)
values ('Tiền Tiêu Vặt', 'WITHDRAW'),
       ('Học Phí', 'WITHDRAW'),
       ('Phí Ăn Uống', 'WITHDRAW'),
       ('Chi Phí Đi Lại', 'WITHDRAW');