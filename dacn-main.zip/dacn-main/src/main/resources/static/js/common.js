function goToCalendar() {
    window.location.href = "/calendar";
}

function logout() {
    window.location.href = "/login";
}

function goToDeposit(){
    window.location.href = "/finance/deposit";
}

function goToWithdraw() {
    window.location.href = "/finance/withdraw";
}

function goToHome() {
    window.location.href = "/home";
}