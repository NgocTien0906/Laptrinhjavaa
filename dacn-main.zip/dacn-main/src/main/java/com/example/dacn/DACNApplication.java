package com.example.dacn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DACNApplication {

	public static void main(String[] args) {
		SpringApplication.run(DACNApplication.class, args);
	}

}
